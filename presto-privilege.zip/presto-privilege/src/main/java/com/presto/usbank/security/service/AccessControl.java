package com.presto.usbank.security.service;

import com.presto.usbank.security.model.RequestAccess;
import com.presto.usbank.security.model.ResponseAccess;

public interface AccessControl {

	ResponseAccess checkCanAccessCatalog(RequestAccess requestAccess);

	ResponseAccess checkCanAccessCatalogRole(RequestAccess requestAccess);

	ResponseAccess checkCanAccessCatalogGroup(RequestAccess requestAccess);

	ResponseAccess checkCanAccessCatalogUser(RequestAccess requestAccess);

	ResponseAccess checkCanAccessCatalogLevel(RequestAccess requestAccess);

	ResponseAccess checkCanAccessSchema(RequestAccess requestAccess);

	ResponseAccess checkCanAccessSchemaRole(RequestAccess requestAccess);

	ResponseAccess checkCanAccessSchemaUser(RequestAccess requestAccess);

	ResponseAccess checkCanAccessSchemaCatalog(RequestAccess requestAccess);

	ResponseAccess checkCanAccessTables(RequestAccess requestAccess);

	ResponseAccess checkCanAccessSystemSessionProperties(RequestAccess requestAccess);

	ResponseAccess checkCanAccessCatalogSessionProperties(RequestAccess requestAccess);

	ResponseAccess checkCanAccessQueries(RequestAccess requestAccess);

	ResponseAccess checkCanAccessImpersonation(RequestAccess requestAccess);

	ResponseAccess checkCanAccessPrincipals(RequestAccess requestAccess);

	ResponseAccess checkCanAccessSystemInformation(RequestAccess requestAccess);

	ResponseAccess checkCanAccessSessionProperties(RequestAccess requestAccess);

}

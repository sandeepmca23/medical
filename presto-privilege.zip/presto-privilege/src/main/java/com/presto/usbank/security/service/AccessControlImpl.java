package com.presto.usbank.security.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.presto.usbank.security.model.RequestAccess;
import com.presto.usbank.security.model.ResponseAccess;
import com.presto.usbank.security.utils.FileSystemAccessControlUtils;
import com.presto.usbank.security.utils.FileSystemAccessControlUtils.Keys;

public class AccessControlImpl implements AccessControl {

	@Override
	public ResponseAccess checkCanAccessCatalogRole(RequestAccess requestAccess) {
		return checkCanAccess(Keys.role.name(), requestAccess.getRole(), Keys.catalogs.name());
	}

	@Override
	public ResponseAccess checkCanAccessCatalogGroup(RequestAccess requestAccess) {
		return checkCanAccess(Keys.group.name(), requestAccess.getGroup(), Keys.catalogs.name());
	}

	@Override
	public ResponseAccess checkCanAccessCatalogUser(RequestAccess requestAccess) {
		return checkCanAccess(Keys.user.name(), requestAccess.getUser(), Keys.catalogs.name());
	}

	@Override
	public ResponseAccess checkCanAccessSchemaCatalog(RequestAccess requestAccess) {
		return checkCanAccess(Keys.catalog.name(), requestAccess.getCatalog(), Keys.catalogs.name());
	}

	@Override
	public ResponseAccess checkCanAccessCatalogLevel(RequestAccess requestAccess) {
		return null;
	}

	private ResponseAccess checkCanAccess(String key, String val, String keys) {
		ResponseAccess responseAccess = new ResponseAccess();
		List<Map<String, Object>> catalogList = null;
		if (key != null)
			catalogList = FileSystemAccessControlUtils.retmap.get(keys).get(key).stream()
					.filter(f -> f.containsValue(val)).collect(Collectors.toList());

		if (catalogList != null && !catalogList.isEmpty() && keys.equals(Keys.catalogs.name())
				&& FileSystemAccessControlUtils.CATALOGS_ALLOW.contains(catalogList.get(0).get("allow")))
			responseAccess.setAllow(Boolean.TRUE);
		else if (catalogList != null && !catalogList.isEmpty() && keys.equals(Keys.schemas.name())
				&& FileSystemAccessControlUtils.CATALOGS_ALLOW.contains(catalogList.get(0).get("owner")))
			responseAccess.setAllow(Boolean.TRUE);
		else
			responseAccess.setAllow(Boolean.FALSE);
		return responseAccess;
	}

	@Override
	public ResponseAccess checkCanAccessCatalog(RequestAccess requestAccess) {
		ResponseAccess responseAccess = new ResponseAccess();
		if (requestAccess.getRole() != null)
			responseAccess = checkCanAccess(Keys.role.name(), requestAccess.getRole(), Keys.catalogs.name());
		else if (requestAccess.getGroup() != null)
			responseAccess = checkCanAccess(Keys.group.name(), requestAccess.getGroup(), Keys.catalogs.name());
		else if (requestAccess.getUser() != null)
			responseAccess = checkCanAccess(Keys.user.name(), requestAccess.getUser(), Keys.catalogs.name());
		else if (requestAccess.getCatalog() != null)
			responseAccess = checkCanAccess(Keys.catalog.name(), requestAccess.getCatalog(), Keys.catalogs.name());
		return responseAccess;
	}

	@Override
	public ResponseAccess checkCanAccessSchema(RequestAccess requestAccess) {
		ResponseAccess responseAccess = new ResponseAccess();
		if (requestAccess.getRole() != null)
			responseAccess = checkCanAccess(Keys.role.name(), requestAccess.getRole(), Keys.schemas.name());
		else if (requestAccess.getGroup() != null)
			responseAccess = checkCanAccess(Keys.group.name(), requestAccess.getGroup(), Keys.schemas.name());
		else if (requestAccess.getUser() != null)
			responseAccess = checkCanAccess(Keys.user.name(), requestAccess.getUser(), Keys.schemas.name());
		else if (requestAccess.getCatalog() != null)
			responseAccess = checkCanAccess(Keys.catalog.name(), requestAccess.getCatalog(), Keys.schemas.name());
		return responseAccess;
	}

	@Override
	public ResponseAccess checkCanAccessQueries(RequestAccess requestAccess) {
		return null;
	}

	@Override
	public ResponseAccess checkCanAccessSchemaRole(RequestAccess requestAccess) {
		return null;
	}

	@Override
	public ResponseAccess checkCanAccessSchemaUser(RequestAccess requestAccess) {
		return null;
	}

	@Override
	public ResponseAccess checkCanAccessTables(RequestAccess requestAccess) {
		return null;
	}

	@Override
	public ResponseAccess checkCanAccessSystemSessionProperties(RequestAccess requestAccess) {
		return null;
	}

	@Override
	public ResponseAccess checkCanAccessCatalogSessionProperties(RequestAccess requestAccess) {
		return null;
	}

	@Override
	public ResponseAccess checkCanAccessImpersonation(RequestAccess requestAccess) {
		return null;
	}

	@Override
	public ResponseAccess checkCanAccessPrincipals(RequestAccess requestAccess) {
		return null;
	}

	@Override
	public ResponseAccess checkCanAccessSystemInformation(RequestAccess requestAccess) {

		return null;
	}

	@Override
	public ResponseAccess checkCanAccessSessionProperties(RequestAccess requestAccess) {

		return null;
	}

	public static void main(String[] args) {
		Map<String, Map<String, List<Map<String, Object>>>> retmap = FileSystemAccessControlUtils.retmap;
		AccessControlImpl accessControlImpl = new AccessControlImpl();
		RequestAccess requestAccess = new RequestAccess();
		requestAccess.setGroup("finance");
		System.out.println(accessControlImpl.checkCanAccessCatalogGroup(requestAccess));
	}

}

package com.presto.usbank.security;

import com.presto.usbank.security.utils.FileSystemAccessControlUtils;

public class AccessControlRun {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		FileSystemAccessControlUtils fileSystemAccessControlUtils = new FileSystemAccessControlUtils();

	}
}

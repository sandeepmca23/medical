package com.presto.usbank.security.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.fasterxml.jackson.databind.ObjectMapper;

@SuppressWarnings("static-access")
public class FileSystemAccessControlUtils {
	private static final String FILE_PATH = "C:/json/rules.json";
	public static Map<String, Map<String, List<Map<String, Object>>>> retmap = new ConcurrentHashMap<>();
	private static final ScheduledExecutorService scheduledThreadPool = Executors.newScheduledThreadPool(1);
	public static List<Object> CATALOGS_ALLOW = Arrays.asList("all", true, "read-only", "none");
	public static List<Boolean> SCHEMAS_OWNER = Arrays.asList(false, true);
	public static List<String> QUERIES_ALLOW = Arrays.asList("execute", "kill", "view", "none");
	public static List<String> PRIVILEGES = Arrays.asList("SELECT", "INSERT", "DELETE", "UPDATE", "OWNERSHIP");

	public FileSystemAccessControlUtils() {
		Thread t = new Thread(new WorkerThread());
		t.start();
	}

	static {
		FileSystemAccessControlUtils fileSystemAccessControlUtils = new FileSystemAccessControlUtils();
		fileSystemAccessControlUtils.loadConfigurationFile();
	}

	public class WorkerThread implements Runnable {
		@Override
		public void run() {
			scheduledThreadPool.schedule(new WorkerThread2(), 1, TimeUnit.MINUTES);
			scheduledThreadPool.shutdown();
			while (!scheduledThreadPool.isTerminated()) {
			}
		}
	}

	public class WorkerThread2 implements Runnable {
		@Override
		public void run() {
			System.out.println("::::::::::::::::::::::");
			loadConfigurationFile();
			System.out.println("::::::::::::::::::::::");
		}
	}

	public enum Keys {
		catalogs, schemas, tables, role, group, user, catalog, property, system_session_properties, catalog_session_properties, queries, impersonation, original_role, principals, principal, system_information, session_properties, original_user
	}

	@SuppressWarnings({ "unchecked", "unused" })
	public static void loadConfigurationFile() {

		try {
			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> obj = mapper.readValue(new File(FILE_PATH), Map.class);
			for (Map.Entry<String, Object> map : obj.entrySet()) {
				List<Map<String, Object>> list = (List<Map<String, Object>>) map.getValue();
				retmap.put(map.getKey(), updatekey(map.getKey(), list));
			}
			String response = mapper.writeValueAsString(retmap);
			System.out.println(response);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static Map<String, List<Map<String, Object>>> updatekey(String key, List<Map<String, Object>> list) {
		Map<String, List<Map<String, Object>>> retmap = new LinkedHashMap<>();
		for (Map<String, Object> ret : list) {
			String keys = null;
			if (key.equals(Keys.catalogs.name())) {
				keys = getKey(ret);
			} else if (key.equals(Keys.schemas.name())) {
				keys = getKey(ret);
			} else if (key.equals(Keys.tables.name())) {
				keys = getKey(ret);
			} else if (key.equals(Keys.system_session_properties.name())) {
				keys = getKey(ret);
			} else if (key.equals(Keys.catalog_session_properties.name())) {
				keys = getKey(ret);
			} else if (key.equals(Keys.queries.name())) {
				keys = getKey(ret);
			} else if (key.equals(Keys.impersonation.name())) {
				keys = getKey(ret);
			} else if (key.equals(Keys.principals.name())) {
				keys = getKey(ret);
			} else if (key.equals(Keys.system_information.name())) {
				keys = getKey(ret);
			} else if (key.equals(Keys.session_properties.name())) {
				keys = getKey(ret);
			}
			updateListMap(ret, retmap, keys);
		}
		return retmap;
	}

	public static String getKey(Map<String, Object> ret) {
		String keys = null;
		if (ret.containsKey(Keys.role.name())) {
			keys = Keys.role.name();
		} else if (ret.containsKey(Keys.group.name())) {
			keys = Keys.group.name();
		} else if (ret.containsKey(Keys.user.name())) {
			keys = Keys.user.name();
		} else if (ret.containsKey(Keys.property.name())) {
			keys = Keys.property.name();
		} else if (ret.containsKey(Keys.original_role.name())) {
			keys = Keys.original_role.name();
		} else if (ret.containsKey(Keys.original_user.name())) {
			keys = Keys.original_user.name();
		} else {
			keys = Keys.catalog.name();
		}

		return keys;
	}

	public static void updateListMap(Map<String, Object> ret, Map<String, List<Map<String, Object>>> retmap,
			String key) {
		if (key != null)
			if (retmap.containsKey(key)) {
				retmap.get(key).add(ret);
			} else {
				List<Map<String, Object>> list1 = new ArrayList<>();
				list1.add(ret);
				retmap.put(key, list1);
			}
	}

}

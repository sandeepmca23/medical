package com.presto.usbank.security.model;

public class ResponseAccess {
	
	@Override
	public String toString() {
		return "ResponseAccess [allow=" + allow + "]";
	}

	private boolean allow;

	public boolean isAllow() {
		return allow;
	}

	public void setAllow(boolean allow) {
		this.allow = allow;
	}

}
